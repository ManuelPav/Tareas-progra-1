package control.de.temperatura;

public class ControlDeTemperatura {

    public static void main(String[] args) {
        Termometro termo = new Termometro(360);
        
        termo.convertirFahrenheit();
        termo.convertirKelvin();
    }
}
