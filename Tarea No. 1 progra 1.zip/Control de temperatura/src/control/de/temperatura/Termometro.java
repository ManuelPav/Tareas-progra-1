package control.de.temperatura;

public class Termometro {
    private double grados;
    
    public Termometro(double grados){
        this.grados = grados;
    }
    
    public double getGrados(){
        return grados;
    }
    
    public void setGrados(double grados){
        this.grados = grados;
    }
    
    public void convertirFahrenheit(){
        double gradosFahrenheit;
        gradosFahrenheit = (this.grados*1.8) + 32;
        System.out.println(this.grados+" grados celcius, equivalen a: "+gradosFahrenheit+" grados Fahrenheit");
    }
    
    public void convertirKelvin(){
        double gradosKelvin = 0.00;
        gradosKelvin = this.grados + 273.15;
        System.out.println(this.grados+" grados celcius, equivalen a: "+gradosKelvin+" grados Kelvin");
    }
}
