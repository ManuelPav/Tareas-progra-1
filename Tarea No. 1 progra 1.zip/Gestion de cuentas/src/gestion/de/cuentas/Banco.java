
package gestion.de.cuentas;

public class Banco {

    public static void main(String[] args) {
        
        CuentaBancaria cuenta1 = new CuentaBancaria("Manuel Mansilla", 123423, 100.00);
        System.out.println("Su numero de cuenta es: "+cuenta1.getNumeroCuenta());
        System.out.println("su saldo inicial es de: "+cuenta1.getSaldoInicial());
        System.out.println("El nombre de la cuenta es: "+cuenta1.getNombreCuenta());
        cuenta1.consultarSaldo();
        cuenta1.depositar(500.30);
        cuenta1.consultarSaldo();
        cuenta1.depositar(400.70);
        cuenta1.consultarSaldo();
        cuenta1.retirar(701);
        cuenta1.consultarSaldo();
        cuenta1.retirar(400);
        cuenta1.consultarSaldo();
    }
}
