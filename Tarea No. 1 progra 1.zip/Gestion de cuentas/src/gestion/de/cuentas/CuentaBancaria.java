package gestion.de.cuentas;

public class CuentaBancaria {
    private String nombreCuenta;
    private int numeroCuenta;
    private double saldoInicial;
    private double saldo;
    

    public CuentaBancaria(String nombreCuenta, int numeroC, double saldoInicial) {
        this.saldo = saldo + saldoInicial;
        this.numeroCuenta = numeroC;
        this.saldoInicial = saldoInicial;
        this.nombreCuenta = nombreCuenta;
    }
    
    public String getNombreCuenta(){
        return nombreCuenta;
    }
    
    public void setNombreCuenta(){
        this.nombreCuenta = nombreCuenta;
    }

    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(int numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public double getSaldoInicial() {
        return saldoInicial;
    }

    public void setSaldoInicial(double saldoInicial) {
        if (saldoInicial <= 0) {
            System.out.println("Error 243: Ingreso de número negativo");
        } else {
            this.saldoInicial = saldoInicial;
            this.saldo = saldo + saldoInicial;
            System.out.println("Saldo ingresado con exito");
        }
    }

    public void depositar(double deposito) {
        if (deposito <= 0) {
            System.err.println("Error 458: ingresó una cantidad invalida");
        } else {
            this.saldo = saldo + deposito;
            System.out.println("se le depositaron :" + "Q" + deposito + " a su cuenta");
        }
    }

    public void retirar(double retiro) {
        if (retiro < 0) {
            System.err.println("Error 675: datos invalidos");
        }
        if (this.saldo < retiro) {
            System.out.println("Error 342: saldo insuficiente");
        } else {
            this.saldo = saldo - retiro;
            System.out.println("se le retiro: "+retiro);
        }
    }

    public void consultarSaldo() {
        System.out.println("su saldo total es de: " + this.saldo);
    }

}
