
package registro.de.productos;

public class RegistroDeProductos {

       public static void main(String[] args) {
        
            Productos producto1 = new Productos("longanizas", 23728, 10.4);
      
                producto1.setCodigo(142);
                producto1.setNombre("Peregil");
                producto1.setPrecio(23);
            
                System.out.println("Nombre: "+producto1.getNombre()+"\n"+
                                     "Codigo: "+producto1.getCodigo()+"\n"+
                                     "Precio: "+producto1.getPrecio());
      
       }
}
