
package sistema.bancario;

public class SistemaBancario {

   public static void main(String[] args){
       
        Cliente cliente1 = new Cliente("Alverto Joaquin Ramirez Garcia", 301218951, "4ta calle 7-24 zona7");
        CuentaBancaria cuenta1 = new CuentaBancaria(89027892, 500.0, cliente1);
        Banco banco = new Banco(cliente1, cuenta1);
     
        banco.mostrarDatos();
       
   }
}
