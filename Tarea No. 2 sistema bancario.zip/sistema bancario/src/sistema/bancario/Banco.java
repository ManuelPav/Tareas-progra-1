
package sistema.bancario;

public class Banco {
    private Cliente cliente;
    private CuentaBancaria cuentaBancaria;

    public Banco(Cliente cliente, CuentaBancaria cuentaBancaria) {
        this.cliente = cliente;
        this.cuentaBancaria = cuentaBancaria;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public CuentaBancaria getCuentaBancaria() {
        return cuentaBancaria;
    }

    public void setCuentaBancaria(CuentaBancaria cuentaBancaria) {
        this.cuentaBancaria = cuentaBancaria;
    }
    
    
    public void mostrarDatos(){
        System.out.println("nombre: "+this.cliente.getNombre()+"\n"+
                           "cuenta: "+this.cuentaBancaria.getNumeroCuenta()+"\n"+
                           "Saldo total: "+this.cuentaBancaria.getSaldo());
    }
    
}
