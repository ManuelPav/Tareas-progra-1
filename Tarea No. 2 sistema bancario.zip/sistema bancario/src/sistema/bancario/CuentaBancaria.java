
package sistema.bancario;

public class CuentaBancaria {
    private int numeroCuenta;
    private double saldo; 
    private Cliente cliente;
    
    public CuentaBancaria(int numeroCuenta, double saldo, Cliente cliente){
        this.cliente = cliente; 
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
    }
    
    public int getNumeroCuenta(){
        return numeroCuenta;
    }
    
    public void setNumeroCuenta(int numeroCuenta){
        this.numeroCuenta = numeroCuenta;
    }
    
    public double getSaldo(){
        return saldo;
    }
    
    public void setSaldo(double saldo){
        if (saldo <= 0){
            System.out.println("Cantidad invalida");
        } else {
            this.saldo = saldo;
        }
    }
    
    public Cliente getCliente(){
        return cliente;
    }
    
    public void setCliente(Cliente cliente){
        this.cliente = cliente;
    }
    
    public void depositar(double deposito){
        if (deposito <= 0 ){
            System.out.println("Lo sentimos la cantidad ingresada es invalida");
        } else {
            this.saldo += deposito;
        }
        
    }
    
    public void retirar(double retiro){
        if (retiro > 0){
            if (saldo>retiro){
                this.saldo -= retiro;
                System.out.println("Su retiro a sido exitoso");
            } else {
                System.out.println("Saldo insuficiente");
            }
        } else {
            System.out.println("Cantidad invalida");
        }
        
    }
    
    public void consultarSaldo(){
        System.out.println("Su saldo es de: "+this.saldo);
    }
    
    public void mostrarDatos(){
        System.out.println("Numero de cuenta: "+this.numeroCuenta+"\n"+
                           "Saldo total: "+this.saldo+"\n"+
                           "Cliente asociado: "+this.cliente);
    }
}
